set terminal postscript eps size 3.5,2.62 enhanced color font 'Helvetica,10' linewidth 2
#set terminal jpeg 200 300 enhanced font 'Helvetica,10' linewidth 2
set output 'JR_F.eps'
set xlabel "DTM size"
set ylabel "F-measure"
set xrange [0.1:0.90]
set key right bottom 
plot 'jackrabbit_F_n3.dat' using 1:11 with linespoints title "RF", \
     'jackrabbit_F_n3.dat' using 1:10 with linespoints title "DT", \
     'jackrabbit_F_n3.dat' using 1:9 with linespoints title "SVM.sigmoid", \
     'jackrabbit_F_n3.dat' using 1:6 with linespoints title "SVM.rbf", \
     'jackrabbit_F_n3.dat' using 1:5 with linespoints title "SVM.linear", \
     'jackrabbit_F_n3.dat' using 1:7 with linespoints title "SVM.poly2", \
     'jackrabbit_F_n3.dat' using 1:8 with linespoints title "SVM.poly3", \
     'jackrabbit_F_n3.dat' using 1:3 with linespoints title "LDA", \
     'jackrabbit_F_n3.dat' using 1:4 with linespoints title "KNN", \
     'jackrabbit_F_n3.dat' using 1:2 with linespoints title "NB"

unset xlabel
unset ylabel
unset output
unset terminal
