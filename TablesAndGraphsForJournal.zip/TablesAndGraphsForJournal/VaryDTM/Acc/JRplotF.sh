set terminal postscript eps size 3.5,2.62 enhanced color font 'Helvetica,10' linewidth 2
set output 'JR_Acc.eps'
set xlabel "DTM size"
set ylabel "Average Accuracy"
set xrange [0.1:0.9]
set key right bottom 
plot 'jackrabbit_Acc_n3.dat' using 1:11 with linespoints title "RF", \
     'jackrabbit_Acc_n3.dat' using 1:10 with linespoints title "DT", \
     'jackrabbit_Acc_n3.dat' using 1:9 with linespoints title "SVM.sigmoid", \
     'jackrabbit_Acc_n3.dat' using 1:6 with linespoints title "SVM.rbf", \
     'jackrabbit_Acc_n3.dat' using 1:5 with linespoints title "SVM.linear", \
     'jackrabbit_Acc_n3.dat' using 1:7 with linespoints title "SVM.poly2", \
     'jackrabbit_Acc_n3.dat' using 1:8 with linespoints title "SVM.poly3", \
     'jackrabbit_Acc_n3.dat' using 1:3 with linespoints title "LDA", \
     'jackrabbit_Acc_n3.dat' using 1:4 with linespoints title "KNN", \
     'jackrabbit_Acc_n3.dat' using 1:2 with linespoints title "NB"

unset xlabel
unset ylabel
unset output
unset terminal
