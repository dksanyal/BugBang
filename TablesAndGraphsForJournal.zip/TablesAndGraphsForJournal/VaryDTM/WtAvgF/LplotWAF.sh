set terminal postscript eps size 3.5,2.62 enhanced color font 'Helvetica,10' linewidth 2
set output 'L_WAF.eps'
set xlabel "DTM size"
set ylabel "Weighted Average F-measure"
set key right bottom 
set xrange[0.1:0.9]
plot 'lucene_wtaF_n3.dat' using 1:11 with linespoints title "RF", \
     'lucene_wtaF_n3.dat' using 1:10 with linespoints title "DT", \
     'lucene_wtaF_n3.dat' using 1:9 with linespoints title "SVM.sigmoid", \
     'lucene_wtaF_n3.dat' using 1:6 with linespoints title "SVM.rbf", \
     'lucene_wtaF_n3.dat' using 1:5 with linespoints title "SVM.linear", \
     'lucene_wtaF_n3.dat' using 1:7 with linespoints title "SVM.poly2", \
     'lucene_wtaF_n3.dat' using 1:8 with linespoints title "SVM.poly3", \
     'lucene_wtaF_n3.dat' using 1:3 with linespoints title "LDA", \
     'lucene_wtaF_n3.dat' using 1:4 with linespoints title "KNN", \
     'lucene_wtaF_n3.dat' using 1:2 with linespoints title "NB"

unset xlabel
unset ylabel
unset output
unset terminal
