#set terminal postscript eps size 3.5,2.62 enhanced color font 'Helvetica,10' linewidth 2
#set output 'TrueNFakeType.eps' 
#'TrueNFakeRF_N_3_Dtm_0.25.eps'
set terminal postscript eps size 3.5,2.62 enhanced color font 'Helvetica,10' linewidth 2
set output 'TrueNFakeType.eps'


set boxwidth 0.95 absolute
set style fill pattern 1 border lt -1 
set grid nopolar
set grid noxtics nomxtics ytics nomytics noztics nomztics \
 nox2tics nomx2tics noy2tics nomy2tics nocbtics nomcbtics
set grid layerdefault   lt 0 linewidth 0.500,  lt 0 linewidth 0.500
set key bmargin center horizontal Left reverse noenhanced autotitle columnhead nobox
set style histogram clustered gap 1 title textcolor lt -1 offset character 2, 0.25
set style data histogram
set xtics border in scale 0,0 nomirror rotate by -45  autojustify
set xtics  norangelimit  font ",10"  
#8
set xtics   ()
set ytics border in scale 0,0 mirror norotate  autojustify
set ytics  norangelimit autofreq  font ",10"
#8
set ztics border in scale 0,0 nomirror norotate  autojustify
set cbtics border in scale 0,0 mirror norotate  autojustify
set rtics axis in scale 0,0 nomirror norotate  autojustify
set xlabel offset 0,-2
set grid y
set auto y

plot newhistogram "HttpClient" fs pattern 1, 'TrueNFakeType.dat' using 2:xtic(1) t col, '' using 3 t col, \
     newhistogram "Lucene" fs pattern 1, 'TrueNFakeType.dat' using 4:xtic(1) t col, '' using 5 t col,  \
     newhistogram "Jackrabbit" fs pattern 1, 'TrueNFakeType.dat' using 6:xtic(1) t col, '' using 7 t col
